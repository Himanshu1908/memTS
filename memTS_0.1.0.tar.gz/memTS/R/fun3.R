#' Simulate an AR(1) Process with a Constant Term and Time Trend
#'
#' @param n Desired sample size (Default = 1)
#' @param phi Coefficient of the AR component
#' @param alpha The constant term (Default = 0)
#' @param beta Coefficient of the time trend (Default = 0)
#' @param sd Standard deviation of the Gaussian innovations (Default = 1)
#' @param burn Non-negative length of burn-ins (Default = 10)
#' @return A time-series object of class "ts".
#' @export
#'
#' @examples
#' ar.p(n = 50, phi = 0.5, alpha = 1, beta = 2)
ar.p = function(n = 1, phi, alpha = 0, beta = 0, sd = 1, burn = 10)
{
  N = n + burn
  x = rep(); e = rnorm(N, mean = 0, sd = sd)
  x[1] = alpha + beta + e[1]
  for(i in 2:N)
  {
    x[i] = alpha + phi*x[i-1] + beta*i + e[i]
  }
  x = as.ts(x[-(1:burn)]); return(x)
}

#' Corrected Score Estimation for AR(1) Model
#'
#' @param w The observed time series sequence
#' @param rho The variance of the measurement error, if any (Default = 0)
#' @param alpha Logical operator, when TRUE the AR(1) model with constant term is estimated (Default = FALSE)
#' @param beta Logical operator, when TRUE the AR(1) model with time trend is estimated (Default = FALSE)
#'
#' @return The corrected score estimates of the model parameters along with the unit root test statistic
#' @export
#'
#' @examples
#' x = ar.p(10^3, phi = 0.5, alpha = 0, beta = 0)
#' ar.cs(x)
#' ar.cs(x, alpha = TRUE)
#' ar.cs(x, beta = TRUE)
#' ar.cs(x, alpha = TRUE, beta = TRUE)
ar.cs = function(w, rho = 0, alpha = FALSE, beta = FALSE){
  n = length(w); w1 = w[1:(n-1)]; w2 = w[2:n]
  if(alpha == TRUE & beta == TRUE){
    a11 = sum(2:n); a21 = (n-1)
    a31 = sum(w1); a12 = sum((2:n)*w1)
    a22 = a31; a32 = sum(w1^2)-((n-1)*rho)
    a13 = sum((2:n)^2); a23 = a11; a33 = a12
    A = matrix(c(a11,a21,a31,a12,a22,a32,a13,a23,a33), nrow = 3, ncol = 3)
    b1 = sum((2:n)*w2); b2 = sum(w2); b3 = sum(w2*w1)
    B = matrix(c(b1,b2,b3), nrow = 3, ncol = 1)
    est = solve(A,B); ur = n*(est[2,] - 1)
    return(list(alpha = est[1,], phi = est[2,], beta = est[3,], unit.root = ur))
  } else if(alpha == TRUE & beta == FALSE){
    NumCS = sum((w1*w2)); DenCS = sum((w1*w1)) - n*rho
    phi.cs = NumCS/DenCS; alpha.cs = mean(w2) - phi.cs*mean(w1)
    ur = n*(phi.cs - 1)
    return(list(alpha = alpha.cs, phi = phi.cs, unit.root = ur))
  } else if(alpha == FALSE & beta == TRUE){
    a11 = sum(2:n); a21 = (n-1)
    a31 = sum(w1); a12 = sum((2:n)*w1)
    a22 = a31; a32 = sum(w1^2)-((n-1)*rho)
    a13 = sum((2:n)^2); a23 = a11; a33 = a12
    A = matrix(c(a11,a21,a31,a12,a22,a32,a13,a23,a33), nrow = 3, ncol = 3)
    b1 = sum((2:n)*w2); b2 = sum(w2); b3 = sum(w2*w1)
    B = matrix(c(b1,b2,b3), nrow = 3, ncol = 1)
    est = solve(A,B); ur = n*(est[2,] - 1)
    return(list(phi = est[2,], beta = est[3,], unit.root = ur))
  } else {
    NumCS = sum((w1*w2)); DenCS = sum((w1*w1)) - n*rho
    ur = n*(NumCS/DenCS - 1)
    return(list(phi = NumCS/DenCS, unit.root = ur))
  }
}

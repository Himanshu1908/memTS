#' Simulate a Linear Regression with AR(p) Innovations
#'
#' @param beta A column vector of regression coefficients
#' @param xreg Design matrix of covariates
#' @param phi Coefficient of the AR component
#' @param sd Standard deviation of the innovation sequence (Default = 1)
#'
#' @return Returns a vector of simulated response variable and the design matrix
#' @export
#'
#' @examples
#' lr.ar.sim(beta = matrix(10,1,1), xreg = matrix(rnorm(100, mean = 0, sd = 1), 100, 1), phi = 0.9, sd = 1)
lr.ar.sim = function(beta, xreg, phi, sd = 1){
  n = apply(xreg, 2, length)[1]
  y = as.numeric(xreg%*%beta + arima.sim(n, model = list(ar = phi), sd = sd))
  return(list(y = y, x = xreg))
}

#' LM Test Statistic for Linear Regression with AR(p) Innovations
#'
#' @param data List of response vector and design matrix
#' @param p Order of the AR component to be modelled
#'
#' @return Returns the LM test statistic
#' @export
#'
#' @examples
#' data = lr.ar.sim(beta = matrix(1,1,1), xreg = matrix(rnorm(100),100,1), phi = c(0.7,0.1), sd = 1)
#' lm.test(data, 2)

lm.test = function(data, p){
  fit = arima(data$y, xreg = data$x, order = c(p,0,0), include.mean = FALSE)
  css = as.numeric(fit$coef); n = apply(data$x, 2, length)[1]
  res = fit$residuals; phi = css[1:p]
  ACF = acf(res, plot = FALSE)$acf
  if(p == 1){
    sqrt(n/phi)*ACF[2]
  } else {
    psi = ARMAtoMA(ar = phi, lag.max = n)
    X = matrix(NA, nrow = n, ncol = p)
    for(k in 1:p){
      X[,k] = c(rep(0,k-1), 1, psi[1:(n-k)])
    }
    Q = (X%*%(solve(t(X)%*%X)))%*%t(X)
    Is = diag(nrow = n); SG = (Is-Q)
    SG = SG[(1:p),(1:p)]; del=rep()
    for(l in 1:(p-1)){
      del[l] = -phi[l] + sum(phi[seq(1, p-1, 1)[1:(p-l)]] * phi[seq(l+1, p, 1)[1:(p-l)]])
    }
    del[p] = -phi[p]; dhat = matrix(del, p, 1)
    rhat = matrix(ACF[2:(p+1)], p, 1)
    NUM = as.numeric((t(dhat)%*%rhat)*sqrt(n))
    DEN = sqrt(as.numeric(t(dhat)%*%SG%*%dhat))
    return(NUM/DEN) 
  }
}
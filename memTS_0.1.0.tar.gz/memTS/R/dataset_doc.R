#' @title Daily INR Exchange Rates Data
#' 
#' @description Contain a data frame of daily exchange rates of INR to USD, GBP and EURO from January 1, 2012 to July 31, 2021
#' 
#' @format Data frame of 3500 observations of 4 variables
#' \describe{
#' \item{DATE}{Observation date}
#' \item{USD_INR}{Rate of 1 USD with respect to INR}
#' \item{EUR_INR}{Rate of 1 EURO with respect to INR}
#' \item{GBP_INR}{Rate of 1 GBP with respect to INR}
#' }
"inr"

#' @title Electricity Consumption Data
#' 
#' @description It is a electricity consumption data by the customers of San Diego Gas and Electric Company.
#' 
#' @format Data frame of 53 observations of 6 variables
#' \describe{
#' \item{KWH}{Logarithm of electricity consumption in KWH (kilo watt hours) per consumer}
#' \item{PCI}{Logarithm of per capita income}
#' \item{PE}{Logarithm of real price of electricity}
#' \item{PG}{Logarithm of real price of gas}
#' \item{CDD}{Cooling degree days}
#' \item{HDD}{Heating degree days}
#' }
"chib93"

#' @title Australian vs. Canadian Dollar Exchange Rate Durations
#' 
#' @description Contains the intra-day exchange rate durations for USD to INR exchange rates. 
#' 
#' @format Data frame of 44037 observations of 1 variable
"auscan"

#' @title US vs. Singapore Dollar Exchange Rate Durations
#' 
#' @description Contains the intra-day exchange rate durations for USD to INR exchange rates. 
#' 
#' @format Data frame of 6933 observations of 1 variable
"ussin"
#' Simulate a Stochastic Volatility (SV) Sequence with Markov Dependent Innovations
#'
#' @param n Desired sample size (Default = 1)
#' @param phi Coefficient of the AR component
#' @param delta Coefficient of the AR component of the innovation sequence
#' @param theta First shape parameter of the GG distribution (Default = 1)
#' @param tau Second shape parameter of the GG distribution (Default = 1)
#' @param lambda Scale parameter of the GG distribution (Default = 1)
#' @param burn Non-negative length of burn-ins (Default = 10)
#'
#' @return A time-series object of class "ts".
#' @export
#'
#' @examples
#' rSVM(n = 100, phi = 0.7, delta = 0.3, theta = 1.5, tau = 0.5, lambda = 1)
rSVM = function(n = 1, phi, delta, theta = 1, tau = 1, lambda = 1, burn = 10)
{
  E = VGAM::rgengamma.stacy(10^6, scale = lambda, d = theta, k = tau)
  U = runif(10^6, 0, pi)
  VE = (E^(1-phi))*(sin(U))*((sin(phi*U))^(-phi))*((sin((1-phi)*U))^(phi-1))
  WT = VE^theta; M = max(WT); PT = WT/M
  VTheta = rep(); VTheta[1] = ifelse(runif(1) < PT[1], VE[1], NA)
  i = 1
  while(length(VTheta[!is.na(VTheta)])!=(n+burn))
  {
    i = i + 1
    VTheta[i] = ifelse(runif(1)<PT[i], VE[i], NA)
  }
  VTheta = VTheta[!is.na(VTheta)]
  BAT = rbeta(n+burn, phi*theta, (1-phi)*theta)
  V = (lambda^(1-phi))*(BAT^(phi/tau))*(VTheta^(1/tau))
  X = rep(); X0 = 1
  X[1] = (X0^phi)*V[1]
  for(i in 2:(n+burn))
  {
    X[i] = (X[i-1]^phi)*V[i]
  }
  X = X[-(1:burn)]
  Z = rep(); Z0 = 1
  Z[1] = delta*Z0 + (sqrt(1-delta^2))*rnorm(1)
  for(i in 2:(n+burn))
  {
    Z[i] = delta*Z[i-1] + (sqrt(1-delta^2))*rnorm(1)
  }
  Z = Z[-(1:burn)]
  x = as.ts(sqrt(X)*Z)
  return(x)
}

#' Mellin Transform of the GG Distribution
#'
#' @param s Order of the Mellin Transform
#' @param theta First shape parameter of the GG distribution (Default = 1)
#' @param tau Second shape parameter of the GG distribution (Default = 1)
#' @param lambda Scale parameter of the GG distribution (Default = 1)
#'
#' @return Expected value of X^s for a GG distributed random variable X.
#' @export
#'
#' @examples
#' mellin.gg(1, theta = 2, tau = 0.5, lambda = 2)
mellin.gg = function(s, theta = 1, tau = 1, lambda = 1)
{
  (1/((lambda^s)*gamma(theta)))*gamma((s/tau)+theta)
}

#' Mellin Transform of X
#' @export
mellin.x = function(s, phi, delta, theta = 1, tau = 1, lambda = 1)
{
  (1/((lambda^s)*gamma(theta)))*gamma((s/tau)+theta)
}

#' Mellin Transform of V
#' @export
mellin.v = function(s, phi, delta, theta = 1, tau = 1, lambda = 1)
{
  res = mellin.x(s, phi, delta, theta, tau, lambda)/mellin.x(phi*s, phi, delta, theta, tau, lambda)
  return(res)
}

#' Sample Moments for GMM estimation with GG Marginals
#'
#' @param y The return sequence to be modelled by SV process
#'
#' @return A vector of 5 sample moments required for GMM estimation
#' @export
#'
#' @examples
#' x = rSVM(n = 10, phi = 0.7, delta = 0.3, theta = 1.5, tau = 0.5, lambda = 1)
#' sample.moments.gg(x)
sample.moments.gg = function(y) {
  m = length(y); y2 = mean(y^2)
  y4 = mean(y^4); y6 = mean(y^6)
  yy = mean(y[2:m]*y[1:(m-1)])
  y2y2 = mean((y[2:m]^2)*(y[1:(m-1)]^2))
  return(c(y2,y4,y6,yy,y2y2))
}

#' Generalised Method of Moments (GMM) Estimation of SV Model with Markov Dependent Innovations
#'
#' @param x The return sequence to be modelled by SV process
#' @param init A vector of initial values for the model parameters
#'
#' @return The GMM estimates of the model parameters
#' @export
#'
#' @examples
#' x = rSVM(100, phi = 0.7, delta = 0.3, theta = 0.5, tau = 1.5, lambda = 2)
#' init = c(0.7, 0.5, 0.5, 1.5, 2)
#' GMM.gg(x, init)
GMM.gg = function(x, init) {
  GMM = function(par) {
    phi = par[1]; delta = par[2]; theta = par[3]; tau = par[4]; lambda = par[5]
    sm = sample.moments.gg(Y); res = rep()
    res[1] = sm[1] - mellin.x(1,phi,delta,theta,tau,lambda)
    res[2] = sm[2] - 3 * mellin.x(2,phi,delta,theta,tau,lambda)
    res[3] = sm[3] - 15 * mellin.x(3,phi,delta,theta,tau,lambda)
    res[4] = sm[4] - delta * mellin.x(0.5*phi+0.5,phi,delta,theta,tau,lambda) * mellin.v(0.5,phi,delta,theta,tau,lambda)
    res[5] = sm[5] - (1+2*(delta^2)) * mellin.x(phi+1,phi,delta,theta,tau,lambda) * mellin.v(1,phi,delta,theta,tau,lambda)
    return(res)
  }
  Y = x; est = nleqslv::nleqslv(init,GMM)$x
  return(list(phi = est[1], delta = est[2], theta = est[3], tau = est[4], lambda = est[5]))
}

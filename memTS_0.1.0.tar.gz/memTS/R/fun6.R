#' Simulate an ACD(p,q) Model
#'
#' @param n Desired sample size (Default = 1)
#' @param model A list of the model parameters with components omega, alpha and beta
#' @param dist Innovation distribution. Options = "exponential", "gamma", "weibull". (Default = "exponential")
#' @param burn Non-negative length of burn-ins (Default = 10)
#' @param shape Shape parameter of the innovation distribution (only if "gamma" or "weibull")
#' @param scale Scale parameter of the innovation distribution (only if "gamma" or "weibull")
#'
#' @return A time-series object of class "ts".
#' @export
#'
#' @examples
#' acdexp.sim(100, model = list(omega = 1, alpha = 0.7))
acd.sim = function(n = 1, model, dist = "exponential", burn = 10, shape, scale){
  omega = model$omega; alpha = model$alpha; beta = model$beta
  p = length(alpha); q = length(beta); pq = max(p,q)
  if(dist == "exponential"){
    x = ps = rep(); ps[1:pq] = rexp(1); x[1:pq] = ps[1:pq]*rexp(1)
    for(h in (pq+1):(n+burn))
    {
      ps[h] = omega + sum(alpha * x[(h-1):(h-p)]) + sum(beta * ps[(h-1):(h-q)])
      x[h] = ps[h]*rexp(1)
    }
    x = as.ts(x[-(1:burn)])
    return(x)
  } else if(dist == "gamma"){
    x = ps = rep(); ps[1:pq] = rgamma(1, shape, scale) 
    x[1:pq] = ps[1:pq]*rgamma(1, shape, scale)
    for(h in (pq+1):(n+burn))
    {
      ps[h] = omega + sum(alpha * x[(h-1):(h-p)]) + 
        sum(beta * ps[(h-1):(h-q)])
      x[h] = ps[h]*rgamma(1, shape, scale)
    }
    x = as.ts(x[-(1:burn)])
    return(x)
  } else if(dist == "weibull"){
    x = ps = rep(); ps[1:pq] = rweibull(1, shape, scale)
    x[1:pq] = ps[1:pq]*rweibull(1, shape, scale)
    for(h in (pq+1):(n+burn))
    {
      ps[h] = omega + sum(alpha * x[(h-1):(h-p)]) + 
        sum(beta * ps[(h-1):(h-q)])
      x[h] = ps[h]*rgamma(1, shape, scale)
    }
    x = as.ts(x[-(1:burn)])
    return(x)
  }
  else {
    return(print("Wrong Innovation Distribution."))
  }
}

#' Conditional Least Squares (CLS) Estimation of ACD(p,q) Model
#'
#' @param x Vector of durations to be modelled
#' @param order Vector representing the order of the particular ACD model to be fitted  
#' @param init Vector of initial values for the model parameters for estimation
#'
#' @return A list of CLS estimates of the parameters for ACD(p,q) model
#' @export
#'
#' @examples
#' x = acd.sim(10^3, model = list(omega = 1, alpha = 0.7, beta = 0.3))
#' fit.acd(x, init = c(1,0.7,0.3), order = c(1,1))
fit.acd = function(x, order, init){
  n = length(x); p = order[1]; q = order[2]; pq = max(p,q); par = init
  ssq = function(par)
  {
    omega = par[1]; alpha = par[2:(p+1)]; beta =  par[(p+2):(p+q+1)]
    psi = rep(); psi[1:pq] = x[1:pq]
    for(j in 2:n){
      psi[j] = omega + sum(alpha * x[(j-1):(j-p)]) + sum(beta * psi[(j-1):(j-q)])
    }
    res = x - psi; ss = sum(res^2)
    return(ss)
  }
  fit = optim(init, ssq)$par; fit
  return(list(omega = fit[1], alpha = fit[2:(p+1)], beta = fit[(p+2):(p+q+1)]))
}

#' Bootstrap Prediction Inerval for Future Durations in ACD(p,q) Model
#'
#' @param x Vector of durations to be modelled
#' @param order Vector representing the order of the particular ACD model to be fitted
#' @param init Vector of initial values for the model parameters for estimation
#' @param npred Number of future durations to be predicted (Default = 1)
#' @param B Number of bootstrap replicates (Default = 10)
#' @param conf.level Confidence level (Default = 0.95)
#'
#' @return A list of future forecasts and its corresponding bootstrap lower and upper intervals
#' @export
#'
#' @examples
#' x = acd.sim(10^3, model = list(omega = 1, alpha = 0.7, beta = 0.3))
#' boot.acd(x, order = c(1,1), init = c(1,0.7,0.3), npred = 5, B = 100)
boot.acd = function(x, order, init, npred = 1, B = 10, conf.level = 0.95){
  n = length(x); p = order[1]; q = order[2]; pq = max(p,q)
  fit = fit.acd(x, order = order, init = init)
  psi = rep(); psi[1:pq] = x[1:pq]
  for(i in (pq+1):n){
    psi[i] = fit$omega + sum(fit$alpha * x[(i-1):(i-p)]) + sum(fit$beta * psi[(i-1):(i-q)]) 
  }
  eps = x/psi; eps = eps/mean(eps)
  seive = matrix(NA, nrow = B, ncol = npred)
  for(j in 1:B){
    epsb = as.numeric(sample(eps, n + npred + 50, replace = TRUE))
    psib = rep(); xb = rep(); xb[1:pq] = x[1:pq]
    psib[1:pq] = xb[1:pq]/epsb[1:pq]
    for(k in (pq+1):(n+50))
    {
      psib[k] = fit$omega + sum(fit$alpha * xb[(k-1):(k-p)]) + sum(fit$beta * psib[(k-1):(k-q)]) 
      xb[k] = psib[k]*epsb[k]
    }
    xb = xb[51:(n+50)]; psib = psib[51:(n+50)]; FAb = epsb[(n+51):(n+50+npred)]
    ReFIT = fit.acd(xb, order = order, init = c(fit$omega,fit$alpha,fit$beta))
    for(l in 1:npred){
      psib[n+l] = ReFIT$omega + sum(ReFIT$alpha * xb[(n+l-1):(n+l-p)]) + sum(ReFIT$beta * psib[(n+l-1):(n+l-q)])
      xb[n+l] = psib[n+l] * FAb[l]
      seive[j,l] = xb[n+l]
    }
  }
  pred = apply(seive, 2, mean)
  pred.lower = apply(seive, 2, quantile, prob = (1-conf.level)/2)
  pred.upper = apply(seive, 2, quantile, prob = (conf.level + (1-conf.level)/2))
  return(list(pred = pred, pred.lower = pred.lower, pred.upper = pred.upper))
}